// Independent Surge adaptation, 2026-11-08. GPL-3.0.
// CDN classification inspired by Sukka (MIT, Copyright (c) 2024 Sukka).
export const VERSION = '2026.11.08.1';
export const PREFIX = 'laincat_bili_';
type Dash = { baseUrl: string; backupUrl: string[] };
type Video = { streamList: { dashVideo?: Dash }[]; dashAudio: Dash[] };
type Store = { read(key: string): string | null; write(value: string, key: string): boolean };
export type Settings = { enabled: boolean; optimize: boolean; diagnostics: boolean };
export const defaults: Settings = { enabled: true, optimize: false, diagnostics: true };
const ends = (host: string, suffix: string) => host === suffix || host.endsWith('.' + suffix);
export function parseHttp(value: unknown): URL | undefined {
    if (typeof value !== 'string' || value.length > 8192) return;
    try {
        const u = new URL(value);
        if (!['https:', 'http:'].includes(u.protocol) || u.username || u.password) return;
        return u;
    } catch { return; }
}
export function isPcdn(host: string): boolean {
    host = host.toLowerCase();
    return ['mcdn.bilivideo.com', 'mcdn.bilivideo.cn', 'mcdn.bilivideo.net', 'szbdyd.com',
        'nexusedgeio.com', 'ahdohpiechei.com', 'mountaintoys.cn', 'bvmlt.top'].some(x => ends(host, x)) ||
        host === 'upos-sz-mirror14b.bilivideo.com' ||
        (ends(host, 'biliapi.net') && host.split('.')[0].includes('pcdn')) ||
        (/^(?:upos|proxy)-/.test(host) && host.split('.')[0].includes('302'));
}
export function isMirror(u: URL): boolean {
    return u.protocol === 'https:' && !u.port && !isPcdn(u.hostname) &&
        /^(?:upos-\w+-(?!302)\w+|(?:upos|proxy)-tf-[a-z0-9-]+)\.(?:bilivideo|akamaized)\.(?:com|net)$/.test(u.hostname) &&
        u.pathname.startsWith('/upgcxcode/');
}
export function readSettings(store?: Store): Settings {
    const result = { ...defaults };
    for (const key of Object.keys(result) as (keyof Settings)[]) {
        let raw: unknown;
        try { raw = store?.read(PREFIX + key); } catch { /* defaults */ }
        if (raw === 'true' || raw === '1') result[key] = true;
        if (raw === 'false' || raw === '0') result[key] = false;
    }
    return result;
}
export function optimizeVideo(video: Video | undefined, settings: Settings) {
    const stats = { representations: 0, pcdn: 0, eligible: 0, changed: 0, noAlternative: 0, unknown: 0 };
    if (!settings.enabled || !video) return stats;
    const items = [...video.streamList.map(x => x.dashVideo).filter((x): x is Dash => !!x), ...video.dashAudio];
    // Bound work, and plan every change before applying any of them.
    if (items.length > 256) throw new Error('representation-limit');
    const plans: { item: Dash; replacement: string; backups: string[] }[] = [];
    for (const item of items) {
        stats.representations++;
        const base = parseHttp(item.baseUrl);
        if (!base) { stats.unknown++; continue; }
        if (!isPcdn(base.hostname)) continue;
        stats.pcdn++;
        const replacement = item.backupUrl.slice(0, 32).find(value => {
            const u = parseHttp(value);
            return u && isMirror(u);
        });
        if (!replacement) { stats.noAlternative++; continue; }
        stats.eligible++;
        if (settings.optimize) {
            // Keep the exact signed URL and the original primary as a fallback.
            plans.push({ item, replacement, backups: [item.baseUrl, ...item.backupUrl.filter(x => x !== replacement)] });
        }
    }
    for (const plan of plans) {
        plan.item.baseUrl = plan.replacement;
        plan.item.backupUrl = plan.backups;
        stats.changed++;
    }
    return stats;
}
export function runAdapter(video: Video | undefined, endpoint: string, store?: Store, log = console.log) {
    const settings = readSettings(store);
    if (!settings.enabled) return;
    let result: ReturnType<typeof optimizeVideo> | undefined;
    let error = false;
    try { result = optimizeVideo(video, settings); } catch { error = true; }
    if (!settings.diagnostics) return;
    // At most approximately 100 events per UTC date and endpoint. Concurrent writes may race.
    const date = new Date().toISOString().slice(0, 10);
    const key = PREFIX + 'log_' + endpoint;
    let count = 0;
    try {
        const previous = JSON.parse(store?.read(key) || '{}');
        if (previous.date === date && Number.isSafeInteger(previous.count) && previous.count >= 0) count = previous.count;
    } catch { /* first event */ }
    if (count >= 100) return;
    try { store?.write(JSON.stringify({ date, count: count + 1 }), key); } catch { /* best effort */ }
    log(JSON.stringify({ version: VERSION, endpoint, mode: settings.optimize ? 'optimize' : 'observe',
        result: error ? 'adapter-error-kept-original' : video ? 'processed' : 'no-video-info', ...result }));
}
export function processPlayback(video: Video | undefined, endpoint: string): void {
    runAdapter(video, endpoint, typeof $persistentStore === 'undefined' ? undefined : $persistentStore);
}
