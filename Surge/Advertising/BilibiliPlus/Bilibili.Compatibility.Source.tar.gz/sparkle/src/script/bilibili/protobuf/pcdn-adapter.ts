// BilibiliPlus extension to the original Bilibili Surge module, 2026-11-08. GPL-3.0.
// Original module source: kokoryh/Sparkle (GitHub repository, not a separate runtime).
// Partial CDN classification inspired by Sukka (MIT, Copyright (c) 2024 Sukka); not an equivalent port.
export const VERSION = '2026.11.08.3';
export const PREFIX = 'laincat_bili_';
type Dash = { baseUrl: string; backupUrl: string[] };
type Segment = { url: string; backupUrl: string[] };
type Video = {
    streamList: { dashVideo?: Dash; segmentVideo?: { segment: Segment[] } }[];
    dashAudio: Dash[];
    dolby?: { audio?: Dash | Dash[] };
    lossLessItem?: { audio?: Dash };
};
type Store = { read(key: string): string | null; write(value: string, key: string): boolean };
export type Settings = { enabled: boolean; optimize: boolean; diagnostics: boolean; extendedStreams: boolean; sortBackups: boolean; telemetry: boolean };
export const defaults: Settings = { enabled: true, optimize: false, diagnostics: true, extendedStreams: false, sortBackups: false, telemetry: false };
const ends = (host: string, suffix: string) => host === suffix || host.endsWith('.' + suffix);
export function parseHttp(value: unknown): URL | undefined {
    if (typeof value !== 'string' || value.length > 8192) return;
    try {
        const u = new URL(value);
        if (!['https:', 'http:'].includes(u.protocol) || u.username || u.password) return;
        return u;
    } catch { return; }
}
export function isPcdn(host: string): boolean {
    host = host.toLowerCase();
    return ['mcdn.bilivideo.com', 'mcdn.bilivideo.cn', 'mcdn.bilivideo.net', 'szbdyd.com',
        'nexusedgeio.com', 'ahdohpiechei.com', 'mountaintoys.cn', 'bvmlt.top'].some(x => ends(host, x)) ||
        host === 'upos-sz-mirror14b.bilivideo.com' ||
        (ends(host, 'biliapi.net') && host.slice(0, -'.biliapi.net'.length).includes('pcdn')) ||
        (/^(?:upos|proxy)-/.test(host) && host.split('.')[0].includes('302'));
}
// os=mcdn can mark a normal-looking mirror URL as PCDN.
export function isPcdnUrl(u: URL): boolean {
    return isPcdn(u.hostname) || (u.pathname.includes('/upgcxcode/') && u.searchParams.get('os') === 'mcdn');
}
export function isMirror(u: URL): boolean {
    return u.protocol === 'https:' && !u.port && !isPcdnUrl(u) &&
        /^(?:upos-\w+-(?!302)\w+|(?:upos|proxy)-tf-[a-z0-9-]+)\.(?:bilivideo|akamaized)\.(?:com|net)$/.test(u.hostname) &&
        u.pathname.startsWith('/upgcxcode/');
}
// Match only documented expiry formats. Zero means no interpretable expiry, not verified validity.
export function signatureDeadline(u: URL): number {
    const positiveSeconds = (value: string | null | undefined) => {
        const n = Number(value);
        return Number.isSafeInteger(n) && n > 0 ? n : 0;
    };
    const deadline = positiveSeconds(u.searchParams.get('deadline'));
    const token = u.searchParams.get('hdnts');
    const akamai = positiveSeconds(token && /(?:^|~)exp=(\d+)/.exec(token)?.[1]);
    return deadline && akamai ? Math.min(deadline, akamai) : deadline || akamai;
}
export function isFreshCandidate(u: URL, now = Date.now() / 1000): boolean {
    const deadline = signatureDeadline(u);
    return deadline === 0 || deadline > now + 60;
}
export function readSettings(store?: Store): Settings {
    const result = { ...defaults };
    for (const key of Object.keys(result) as (keyof Settings)[]) {
        let raw: unknown;
        try { raw = store?.read(PREFIX + key); } catch { /* defaults */ }
        if (raw === 'true' || raw === '1') result[key] = true;
        if (raw === 'false' || raw === '0') result[key] = false;
    }
    return result;
}
export function optimizeVideo(video: Video | undefined, settings: Settings) {
    const stats = { representations: 0, pcdn: 0, eligible: 0, changed: 0, noAlternative: 0, unknown: 0,
        reordered: 0, dolby: 0, lossless: 0, segments: 0, rejectedExpired: 0, rejectedPcdn: 0 };
    if (!settings.enabled || !video) return stats;
    // Community schema defines these as mutually exclusive oneof members.
    if (video.streamList.some(x => x.dashVideo && x.segmentVideo)) throw new Error('ambiguous-stream');
    type Item = { source: Dash | Segment; key: 'baseUrl' | 'url' };
    const items: Item[] = [
        ...video.streamList.filter(x => !!x.dashVideo).map(x => ({ source: x.dashVideo!, key: 'baseUrl' as const })),
        ...video.dashAudio.map(source => ({ source, key: 'baseUrl' as const })),
    ];
    if (settings.extendedStreams) {
        const dolby = video.dolby?.audio;
        const audios = Array.isArray(dolby) ? dolby : dolby ? [dolby] : [];
        stats.dolby = audios.length;
        items.push(...audios.map(source => ({ source, key: 'baseUrl' as const })));
        if (video.lossLessItem?.audio) {
            stats.lossless++;
            items.push({ source: video.lossLessItem.audio, key: 'baseUrl' });
        }
        for (const stream of video.streamList) for (const source of stream.segmentVideo?.segment || []) {
            stats.segments++;
            items.push({ source, key: 'url' });
        }
    }
    // Bound work; plan every change before touching the message. Never fetch or fabricate a URL.
    if (items.length > 256) throw new Error('representation-limit');
    const plans: { item: Item; replacement: string; backups: string[]; reordered: boolean }[] = [];
    for (const item of items) {
        stats.representations++;
        const primary = item.key === 'url' ? (item.source as Segment).url : (item.source as Dash).baseUrl;
        const base = parseHttp(primary);
        if (!base) { stats.unknown++; continue; }
        const pcdn = isPcdnUrl(base);
        if (pcdn) stats.pcdn++;
        // First 32 candidates are examined; the untouched tail and every distinct fallback are retained.
        const preferred: string[] = [];
        for (const value of item.source.backupUrl.slice(0, 32)) {
            const u = parseHttp(value);
            if (!u || value === primary) continue;
            if (isPcdnUrl(u)) { stats.rejectedPcdn++; continue; }
            if (!isMirror(u)) continue;
            if (!isFreshCandidate(u)) { stats.rejectedExpired++; continue; }
            if (!preferred.includes(value)) preferred.push(value);
        }
        const replacement = pcdn ? preferred[0] : primary;
        if (pcdn && !replacement) { stats.noAlternative++; continue; }
        if (pcdn) stats.eligible++;
        if (!settings.optimize) continue;
        const selected = replacement!;
        const rest = item.source.backupUrl.filter(x => x !== selected);
        let backups = pcdn ? [primary, ...rest] : [...rest];
        if (settings.sortBackups) {
            const good = preferred.filter(x => x !== selected);
            // Stable partition only; no speed claims or speculative CDN rankings.
            backups = [...good, ...backups.filter(x => !good.includes(x))];
        }
        const reordered = backups.length !== item.source.backupUrl.length || backups.some((x, i) => x !== item.source.backupUrl[i]);
        if (selected !== primary || (settings.sortBackups && reordered)) {
            plans.push({ item, replacement: selected, backups, reordered: settings.sortBackups && reordered });
        }
    }
    for (const plan of plans) {
        if (plan.item.key === 'url') (plan.item.source as Segment).url = plan.replacement;
        else (plan.item.source as Dash).baseUrl = plan.replacement;
        plan.item.source.backupUrl = plan.backups;
        stats.changed++;
        if (plan.reordered) stats.reordered++;
    }
    return stats;
}
export function runAdapter(video: Video | undefined, endpoint: string, store?: Store, log = console.log) {
    const settings = readSettings(store);
    if (!settings.enabled) return;
    let result: ReturnType<typeof optimizeVideo> | undefined;
    let error = false;
    try { result = optimizeVideo(video, settings); } catch { error = true; }
    if (!settings.diagnostics) return;
    // At most approximately 100 events per UTC date and endpoint. Concurrent writes may race.
    const date = new Date().toISOString().slice(0, 10);
    const key = PREFIX + 'log_' + endpoint;
    let count = 0;
    try {
        const previous = JSON.parse(store?.read(key) || '{}');
        if (previous.date === date && Number.isSafeInteger(previous.count) && previous.count >= 0) count = previous.count;
    } catch { /* first event */ }
    if (count >= 100) return;
    try { store?.write(JSON.stringify({ date, count: count + 1 }), key); } catch { /* best effort */ }
    log(JSON.stringify({ version: VERSION, endpoint, mode: settings.optimize ? 'optimize' : 'observe',
        result: error ? 'adapter-error-no-url-change' : video ? 'processed' : 'no-video-info', ...result }));
}
export function processPlayback(video: Video | undefined, endpoint: string): void {
    runAdapter(video, endpoint, typeof $persistentStore === 'undefined' ? undefined : $persistentStore);
}
