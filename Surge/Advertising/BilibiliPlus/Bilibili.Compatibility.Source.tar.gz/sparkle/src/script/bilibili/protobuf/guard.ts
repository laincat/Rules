import { Middleware } from '@core/middleware';
import { exit } from '@core/process';

export const guardGrpcFrame: Middleware = (ctx, next) => {
    const bytes = ctx.response.bodyBytes;
    const cap = 2 * 1024 * 1024;
    // This adapter only supports one complete unary gRPC message. Never truncate or guess.
    if (!(bytes instanceof Uint8Array) || bytes.length < 5 || bytes.length > cap || bytes[0] > 1) exit();
    const length = new DataView(bytes.buffer, bytes.byteOffset + 1, 4).getUint32(0);
    if (length !== bytes.length - 5 || ctx.response.status !== 200) exit();
    const headers = ctx.response.headers;
    const trailers = ctx.response.h2_trailers;
    const status = trailers?.['grpc-status'] ?? headers['grpc-status'];
    if (status !== undefined && String(status) !== '0') exit();
    if (bytes[0] === 1) {
        // Check gzip magic and ISIZE before using Surge's decompressor.
        if (length < 18 || bytes[5] !== 31 || bytes[6] !== 139 || bytes[7] !== 8) exit();
        const expanded = new DataView(bytes.buffer, bytes.byteOffset + bytes.length - 4, 4).getUint32(0, true);
        if (expanded > cap) exit();
    }
    return next();
};

export const guardDecodedSize: Middleware = (ctx, next) => {
    if (ctx.response.bodyBytes.length > 2 * 1024 * 1024) exit();
    return next().then(() => {
        // Let Surge compute the new content length for the rewritten frame.
        const headers = { ...ctx.response.headers };
        for (const key of Object.keys(headers)) if (key.toLowerCase() === 'content-length') delete headers[key];
        ctx.response.headers = headers;
    });
};
