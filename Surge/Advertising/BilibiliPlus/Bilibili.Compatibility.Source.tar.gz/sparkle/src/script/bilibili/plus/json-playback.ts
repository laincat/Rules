// BilibiliPlus JSON playback response adapter. GPL-3.0.
// Endpoint/schema evidence: Sukka (MIT), pinned c87b7e7, core/player/playinfo.ts and registry.ts.
// Only existing URLs are reordered. This is not the webpage player/SDK interceptor.
import { readSettings, runAdapter } from '../protobuf/pcdn-adapter';

type RecordValue = Record<string, unknown>;
type Dash = { baseUrl: string; backupUrl: string[] };
type Store = { read(key: string): string | null; write(value: string, key: string): boolean };
const MAX_BYTES = 2 * 1024 * 1024;
const object = (x: unknown): x is RecordValue => !!x && typeof x === 'object' && !Array.isArray(x);
const paths: Record<string, string> = {
    '/x/player/playurl': 'json-playurl',
    '/x/player/wbi/playurl': 'json-wbi-playurl',
    '/pgc/player/web/playurl': 'json-pgc-playurl',
};
export function endpointOf(value: string): string | undefined {
    try {
        const u = new URL(value);
        if (u.protocol !== 'https:' || u.hostname !== 'api.bilibili.com' || u.port || u.username || u.password || u.hash) return;
        return paths[u.pathname];
    } catch { return; }
}
function same(a: unknown, b: unknown): boolean { return JSON.stringify(a) === JSON.stringify(b); }
// JSON.parse cannot preserve integers outside IEEE-754's exact range. Leave those responses untouched.
export function hasUnsafeInteger(text: string): boolean {
    const tokens = text.match(/"(?:[^"\\]|\\.)*"|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/g) || [];
    return tokens.some(t => t[0] !== '"' && (!Number.isFinite(Number(t)) || (Number.isInteger(Number(t)) && !Number.isSafeInteger(Number(t)))));
}
export function adaptJson(body: string, endpoint: string, store?: Store, log = console.log): string | undefined {
    const settings = readSettings(store);
    if (!settings.enabled || !Object.values(paths).includes(endpoint) || body.length > MAX_BYTES || new TextEncoder().encode(body).length > MAX_BYTES || hasUnsafeInteger(body)) return;
    const json: unknown = JSON.parse(body);
    if (!object(json) || json.code !== 0) return;
    // Known envelopes, selected only for the matching endpoint. Never recursively traverse arbitrary data.
    const envelope = endpoint === 'json-pgc-playurl' ? json.result : json.data;
    if (!object(envelope)) return;
    const info = object(envelope.video_info) ? envelope.video_info : envelope;
    if (!object(info.dash)) return; // JSON durl/live shapes are deliberately not modified here.
    const dash = info.dash;
    const commits: (() => void)[] = [];
    let count = 0;
    const normalize = (value: unknown): Dash | undefined => {
        if (!object(value) || ++count > 256) throw new Error('representation-limit');
        const baseKeys = ['baseUrl', 'base_url'].filter(k => Object.hasOwn(value, k));
        const backupKeys = ['backupUrl', 'backup_url'].filter(k => Object.hasOwn(value, k));
        if (!baseKeys.length || typeof value[baseKeys[0]] !== 'string') return;
        if (baseKeys.some(k => value[k] !== value[baseKeys[0]])) return; // Conflicting aliases are ambiguous.
        const backups = backupKeys.length ? value[backupKeys[0]] : [];
        if (!Array.isArray(backups) || backups.length > 256 || backups.some(x => typeof x !== 'string') || backupKeys.some(k => !same(value[k], backups))) return;
        const normalized: Dash = { baseUrl: value[baseKeys[0]] as string, backupUrl: [...backups] as string[] };
        commits.push(() => {
            if (normalized.baseUrl === value[baseKeys[0]] && same(normalized.backupUrl, backups)) return;
            for (const k of baseKeys) value[k] = normalized.baseUrl;
            for (const k of backupKeys) value[k] = normalized.backupUrl;
        });
        return normalized;
    };
    const list = (value: unknown): Dash[] => {
        if (value == null) return [];
        if (!Array.isArray(value) || value.length > 256) throw new Error('invalid-array');
        return value.map(normalize).filter((x): x is Dash => !!x);
    };
    const video = {
        streamList: list(dash.video).map(dashVideo => ({ dashVideo })),
        dashAudio: list(dash.audio),
        dolby: undefined as { audio: Dash[] } | undefined,
        lossLessItem: undefined as { audio: Dash } | undefined,
    };
    if (settings.extendedStreams) {
        if (object(dash.dolby) && dash.dolby.audio != null) video.dolby = { audio: list(dash.dolby.audio) };
        if (object(dash.flac) && object(dash.flac.audio)) {
            const audio = normalize(dash.flac.audio);
            if (audio) video.lossLessItem = { audio };
        }
    }
    const original = JSON.stringify(json);
    runAdapter(video, endpoint, store, log);
    if (!settings.optimize) return;
    // runAdapter plans all URL changes before applying; only copy mapped address fields back.
    for (const commit of commits) commit();
    const result = JSON.stringify(json);
    return result === original ? undefined : result;
}
export function main(): void {
    let done: { body?: string } = {};
    try {
        const endpoint = endpointOf($request.url);
        const contentType = Object.entries($response.headers).find(([k]) => k.toLowerCase() === 'content-type')?.[1] || '';
        if (endpoint && $request.method === 'GET' && ('status' in $response && $response.status === 200) && typeof $response.body === 'string' && /^application\/(?:[\w.+-]+\+)?json\b/i.test(contentType)) {
            const body = adaptJson($response.body, endpoint, typeof $persistentStore === 'undefined' ? undefined : $persistentStore);
            if (body !== undefined) done = { body };
        }
    } catch { /* Fail open without logging the URL, body, authentication data or parse error. */ }
    $done(done);
}
if (typeof $request !== 'undefined' && typeof $response !== 'undefined' && typeof $done !== 'undefined') main();
