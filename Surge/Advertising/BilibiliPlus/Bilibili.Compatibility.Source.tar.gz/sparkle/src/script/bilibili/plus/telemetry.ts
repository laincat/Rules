// BilibiliPlus optional web/WebView telemetry control. GPL-3.0.
// Inspired by Sukka's defuse-spyware (MIT), but intentionally much narrower.
// Evidence: https://s1.hdslb.com/bfs/seed/log/report/log-reporter.js uses
// data.bilibili.com/log/web for sendBeacon. This does NOT prove native App semantics.
// Do not add /v2/log/web, identity/fingerprint/Gaia, history or progress APIs here.
// Surge mock-response API: https://manual.nssurge.com/scripting/http-request.html
import type { Done, HttpRequestDone } from '../../../types/surge';

type Store = { read(key: string): string | null };
type Request = { url?: string; method?: string; headers?: Record<string, string> };
const prefix = 'laincat_bili_';

function flag(store: Store | undefined, key: string, fallback: boolean): boolean {
    const value = store?.read(prefix + key);
    if (value === 'true' || value === '1') return true;
    if (value === 'false' || value === '0') return false;
    return fallback;
}
function header(headers: Request['headers'], name: string): string | undefined {
    if (!headers || Array.isArray(headers)) return;
    const matches = Object.entries(headers).filter(([key]) => key.toLowerCase() === name);
    if (matches.length !== 1 || typeof matches[0][1] !== 'string') return;
    return matches[0][1];
}
function biliWebOrigin(value: string | undefined): string | undefined {
    if (!value || value.length > 8192) return;
    try {
        const u = new URL(value);
        if (u.protocol !== 'https:' || u.port || u.username || u.password) return;
        if (u.hostname !== 'bilibili.com' && !u.hostname.endsWith('.bilibili.com')) return;
        return u.origin;
    } catch { return; }
}

// Pure function for fixture tests. No body reads, logging, requests or persistent writes.
export function telemetryResponse(request: Request, store?: Store): HttpRequestDone {
    try {
        if (!flag(store, 'enabled', true) || !flag(store, 'telemetry', false)) return {};
        if (!['GET', 'POST'].includes(request.method || '')) return {};
        if (typeof request.url !== 'string' || request.url.length > 32768) return {};
        const u = new URL(request.url);
        if (u.protocol !== 'https:' || u.port || u.username || u.password ||
            u.hostname !== 'data.bilibili.com' || u.pathname !== '/log/web') return {};
        const originHeader = header(request.headers, 'origin');
        // An explicit invalid/null Origin must not fall back to Referer.
        const hasOrigin = Object.keys(request.headers || {}).some(key => key.toLowerCase() === 'origin');
        const origin = biliWebOrigin(hasOrigin ? originHeader : header(request.headers, 'referer'));
        if (!origin) return {};
        return { response: { status: 200, headers: {
            'Content-Type': 'text/plain; charset=utf-8',
            'Cache-Control': 'no-store',
            'Access-Control-Allow-Origin': origin,
            'Access-Control-Allow-Credentials': 'true',
            'Vary': 'Origin',
        }, body: 'ok' } };
    } catch {
        // Unknown input or unavailable storage fails open; never print the request.
        return {};
    }
}

if (typeof $request !== 'undefined' && typeof $done === 'function') {
    ($done as Done)(telemetryResponse($request, typeof $persistentStore === 'undefined' ? undefined : $persistentStore));
}
