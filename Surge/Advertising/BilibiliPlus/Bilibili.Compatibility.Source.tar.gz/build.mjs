import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from './sparkle/node_modules/esbuild/lib/main.js';
const root = path.dirname(fileURLToPath(import.meta.url));
const output = path.join(root, 'release');
await fs.mkdir(output, { recursive: true });
await build({ entryPoints: [path.join(root, 'sparkle/src/script/bilibili/protobuf/response/main.ts')],
    bundle: true, minify: true, format: 'iife', target: 'es2022',
    tsconfig: path.join(root, 'sparkle/tsconfig.json'),
    outfile: path.join(output, 'Bilibili.Compatibility.js'),
    banner: { js: '// BilibiliPlus for Surge 2026.11.08.2 | GPL-3.0\n// Original Bilibili Surge module: kokoryh/Sparkle repository, d513a2e.\n// Partial CDN classification inspired by Sukka (MIT); not a complete userscript port. See source bundle and licenses.' } });
const base = process.env.ASSET_BASE_URL || 'https://example.invalid/bilibili';
if (!/^https:\/\/[a-z0-9.-]+(?:\/[^\s,]*)?$/i.test(base)) throw new Error('ASSET_BASE_URL must be an HTTPS directory URL');
const upstream = await fs.readFile(path.join(root, 'sparkle/release/surge/module/bilibili.sgmodule'), 'utf8');
const pin = 'd513a2eeab382c640ccd5d6ecd76e07c4828b1ed';
let module = upstream.replace('#!name=哔哩哔哩增强', '#!name=BilibiliPlus · 哔哩哔哩增强（Surge）')
    .replace('#!desc=拜托，没有广告的哔哩哔哩真的超酷的', '#!desc=2026.11.08.2。基于 kokoryh/Sparkle 仓库的原 B站 Surge 模块整合，勿与原模块同时开启。BoxJS 仅控制新增功能；地址优化默认关闭、诊断开启。仅部分借鉴 Sukka，非完整移植。')
    .replaceAll('https://raw.githubusercontent.com/kokoryh/Sparkle/refs/heads/master/', `https://raw.githubusercontent.com/kokoryh/Sparkle/${pin}/`);
// Keep all non-playback responses on upstream, without the experimental 2MiB limit.
module = module.split('\n').flatMap(line => {
    if (!line.startsWith('bilibili.protobuf.response =')) return [line];
    const originalPattern = line.match(/pattern=(.*?),argument=/)[1];
    const generalPattern = originalPattern
        .replace('|playurl\\.v1\\.PlayURL\\/PlayView|playerunite\\.v1\\.Player\\/PlayViewUnite', '')
        .replace('|pgc\\.gateway\\.player\\.v2\\.PlayURL\\/PlayView', '');
    if (generalPattern === originalPattern || generalPattern.includes('PlayView')) throw new Error('Upstream pattern changed; review required');
    const playbackPattern = '^https:\\/\\/(?:grpc\\.biliapi\\.net|app\\.bilibili\\.com)\\/bilibili\\.(?:app\\.(?:playurl\\.v1\\.PlayURL\\/PlayView|playerunite\\.v1\\.Player\\/PlayViewUnite)|pgc\\.gateway\\.player\\.v2\\.PlayURL\\/PlayView)$';
    const playback = line.replace('bilibili.protobuf.response =', 'bilibili.compat.playback =')
        .replace(originalPattern, playbackPattern).replace('max-size=-1', 'max-size=2097152')
        .replace(`script-path=https://raw.githubusercontent.com/kokoryh/Sparkle/${pin}/dist/bilibili.protobuf.response.js`, `script-path=${base}/Bilibili.Compatibility.js`);
    return [line.replace(originalPattern, generalPattern), playback];
}).join('\n');
await fs.writeFile(path.join(output, 'Bilibili.Compatibility.sgmodule'), module);
const app = {
    id: 'laincat.bilibili.compat', name: 'BilibiliPlus（Surge）', author: 'Laincat',
    keys: ['laincat_bili_enabled', 'laincat_bili_optimize', 'laincat_bili_diagnostics'],
    settings: [
        { id: 'laincat_bili_enabled', name: '新增功能总开关', val: true, type: 'boolean', desc: '仅控制 BilibiliPlus 新增的优化和诊断；不关闭原 B站 Surge 模块已有的去广告、P2P 端口或 tracker 规则。' },
        { id: 'laincat_bili_optimize', name: '优先非 PCDN 备用地址（实验）', val: false, type: 'boolean', desc: '仅从同一 DASH 音视频表示的已有备用地址中优选镜像，排除已识别 PCDN（含 os=mcdn）。跳过已知不超过60秒的签名，不测速、不保证消除所有 PCDN；保留原地址供客户端回退。默认关闭。' },
        { id: 'laincat_bili_diagnostics', name: '脱敏诊断日志', val: true, type: 'boolean', desc: '仅控制新增诊断，独立于模块的原有日志等级。记录接口类别和计数，不记录 URL、Cookie、token、视频 ID 或响应原文。每接口每日约100条。' },
    ],
};
await fs.writeFile(path.join(output, 'Bilibili.Compatibility.boxjs.json'), JSON.stringify({ id: 'laincat.bilibili.subscription', name: 'BilibiliPlus · Surge 设置', author: 'Laincat', apps: [app] }, null, 2) + '\n');
console.log(base.includes('example.invalid') ? 'Built REVIEW ONLY: no publication URL configured.' : `Built for ${base}; publication has NOT been performed.`);
