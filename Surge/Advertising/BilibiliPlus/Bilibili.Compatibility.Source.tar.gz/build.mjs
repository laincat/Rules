import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from './sparkle/node_modules/esbuild/lib/main.js';
const root = path.dirname(fileURLToPath(import.meta.url));
const output = path.join(root, 'release');
await fs.mkdir(output, { recursive: true });
await build({ entryPoints: [path.join(root, 'sparkle/src/script/bilibili/protobuf/response/main.ts')],
    bundle: true, minify: true, format: 'iife', target: 'es2022',
    tsconfig: path.join(root, 'sparkle/tsconfig.json'),
    outfile: path.join(output, 'Bilibili.Compatibility.js'),
    banner: { js: '// BilibiliPlus for Surge 2026.11.08.3 | GPL-3.0\n// Original Bilibili Surge module: kokoryh/Sparkle repository, d513a2e.\n// Partial CDN classification inspired by Sukka (MIT); not a complete userscript port. See source bundle and licenses.' } });
await build({ entryPoints: [path.join(root, 'sparkle/src/script/bilibili/plus/telemetry.ts')],
    bundle: true, minify: true, format: 'iife', target: 'es2022',
    tsconfig: path.join(root, 'sparkle/tsconfig.json'),
    outfile: path.join(output, 'Bilibili.Telemetry.js'),
    banner: { js: '// BilibiliPlus optional web telemetry 2026.11.08.3 | GPL-3.0 | default OFF' } });
await build({ entryPoints: [path.join(root, 'sparkle/src/script/bilibili/plus/json-playback.ts')],
    bundle: true, minify: true, format: 'iife', target: 'es2022',
    tsconfig: path.join(root, 'sparkle/tsconfig.json'),
    outfile: path.join(output, 'Bilibili.JsonPlayback.js'),
    banner: { js: '// BilibiliPlus JSON playback 2026.11.08.3 | GPL-3.0 | partial Sukka-inspired adapter' } });
const base = process.env.ASSET_BASE_URL || 'https://example.invalid/bilibili';
if (!/^https:\/\/[a-z0-9.-]+(?:\/[^\s,]*)?$/i.test(base)) throw new Error('ASSET_BASE_URL must be an HTTPS directory URL');
const upstream = await fs.readFile(path.join(root, 'sparkle/release/surge/module/bilibili.sgmodule'), 'utf8');
const pin = 'd513a2eeab382c640ccd5d6ecd76e07c4828b1ed';
let module = upstream.replace('#!name=哔哩哔哩增强', '#!name=BilibiliPlus · 哔哩哔哩增强（Surge）')
    .replace('#!desc=拜托，没有广告的哔哩哔哩真的超酷的', '#!desc=2026.11.08.3。基于 kokoryh/Sparkle 仓库的原 B站 Surge 模块整合，勿与原模块同时开启。BoxJS 仅控制新增功能；地址优化默认关闭、诊断开启。仅部分借鉴 Sukka，非完整移植。')
    .replaceAll('https://raw.githubusercontent.com/kokoryh/Sparkle/refs/heads/master/', `https://raw.githubusercontent.com/kokoryh/Sparkle/${pin}/`);
// Keep all non-playback responses on upstream, without the experimental 2MiB limit.
module = module.split('\n').flatMap(line => {
    if (!line.startsWith('bilibili.protobuf.response =')) return [line];
    const originalPattern = line.match(/pattern=(.*?),argument=/)[1];
    const generalPattern = originalPattern
        .replace('|playurl\\.v1\\.PlayURL\\/PlayView|playerunite\\.v1\\.Player\\/PlayViewUnite', '')
        .replace('|pgc\\.gateway\\.player\\.v2\\.PlayURL\\/PlayView', '');
    if (generalPattern === originalPattern || generalPattern.includes('PlayView')) throw new Error('Upstream pattern changed; review required');
    const playbackPattern = '^https:\\/\\/(?:grpc\\.biliapi\\.net|app\\.bilibili\\.com)\\/bilibili\\.(?:app\\.(?:playurl\\.v1\\.PlayURL\\/PlayView|playerunite\\.v1\\.Player\\/PlayViewUnite)|pgc\\.gateway\\.player\\.v2\\.PlayURL\\/PlayView)$';
    const playback = line.replace('bilibili.protobuf.response =', 'bilibili.compat.playback =')
        .replace(originalPattern, playbackPattern).replace('max-size=-1', 'max-size=2097152')
        .replace(`script-path=https://raw.githubusercontent.com/kokoryh/Sparkle/${pin}/dist/bilibili.protobuf.response.js`, `script-path=${base}/Bilibili.Compatibility.js`);
    return [line.replace(originalPattern, generalPattern), playback];
}).join('\n');
module = module.replace('[MITM]', 'bilibili.plus.telemetry = type=http-request,pattern=^https:\\/\\/data\\.bilibili\\.com\\/log\\/web(?:\\?|$),requires-body=0,engine=webview,timeout=5,script-path=' + base + '/Bilibili.Telemetry.js\n\n[MITM]')
    .replace('hostname = %APPEND% ', 'hostname = %APPEND% data.bilibili.com, ');
module = module.replace('[MITM]', 'bilibili.plus.json-playback = type=http-response,pattern=^https:\\/\\/api\\.bilibili\\.com\\/(?:x\\/player\\/(?:wbi\\/)?playurl|pgc\\/player\\/web\\/playurl)(?:\\?|$),requires-body=1,max-size=2097152,engine=webview,timeout=10,script-path=' + base + '/Bilibili.JsonPlayback.js\n\n[MITM]');
await fs.writeFile(path.join(output, 'Bilibili.Compatibility.sgmodule'), module);
const app = {
    id: 'laincat.bilibili.compat', name: 'BilibiliPlus（Surge）', author: 'Laincat',
    keys: ['laincat_bili_enabled', 'laincat_bili_optimize', 'laincat_bili_diagnostics', 'laincat_bili_extendedStreams', 'laincat_bili_sortBackups', 'laincat_bili_telemetry'],
    settings: [
        { id: 'laincat_bili_telemetry', name: '网页统计上报抑制（实验）', val: false, type: 'boolean', desc: '仅抑制带有B站HTTPS网页来源标记的 data.bilibili.com/log/web 请求，本地返回成功；不覆盖原生App所有上报。不处理账户/历史/播放进度。默认关闭。' },
        { id: 'laincat_bili_extendedStreams', name: '扩展音轨与分段流（实验）', val: false, type: 'boolean', desc: '将相同地址优选扩展到已返回的 Dolby 音轨、Unite HiRes 音轨和分段视频；不增加账号权限。须同时开启地址优化才修改，默认关闭。' },
        { id: 'laincat_bili_sortBackups', name: '备用地址排序（实验）', val: false, type: 'boolean', desc: '把前32个候选中已识别、未过期的 HTTPS 非PCDN镜像排在其它备用地址前，保留原地址；不测速、不保证客户端按顺序重试。须开启地址优化。默认关闭。' },
        { id: 'laincat_bili_enabled', name: '新增功能总开关', val: true, type: 'boolean', desc: '仅控制 BilibiliPlus 新增的优化和诊断；不关闭原 B站 Surge 模块已有的去广告、P2P 端口或 tracker 规则。' },
        { id: 'laincat_bili_optimize', name: '优先非 PCDN 备用地址（实验）', val: false, type: 'boolean', desc: '仅从同一音视频表示的已有备用地址中优选镜像，排除已识别 PCDN（含 os=mcdn）。跳过已知不超过60秒的签名，不测速、不保证消除所有 PCDN；保留原地址供客户端回退。默认关闭。' },
        { id: 'laincat_bili_diagnostics', name: '脱敏诊断日志', val: true, type: 'boolean', desc: '仅控制新增诊断，独立于模块的原有日志等级。记录接口类别和计数，不记录 URL、Cookie、token、视频 ID 或响应原文。每接口每日约100条。' },
    ],
};
const order = ['enabled', 'optimize', 'extendedStreams', 'sortBackups', 'telemetry', 'diagnostics'];
app.settings.sort((a, b) => order.indexOf(a.id.replace('laincat_bili_', '')) - order.indexOf(b.id.replace('laincat_bili_', '')));
await fs.writeFile(path.join(output, 'Bilibili.Compatibility.boxjs.json'), JSON.stringify({ id: 'laincat.bilibili.subscription', name: 'BilibiliPlus · Surge 设置', author: 'Laincat', apps: [app] }, null, 2) + '\n');
console.log(base.includes('example.invalid') ? 'Built REVIEW ONLY: no publication URL configured.' : `Built for ${base}; publication has NOT been performed.`);
