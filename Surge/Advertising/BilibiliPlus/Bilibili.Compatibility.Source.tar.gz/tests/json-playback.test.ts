import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import { buildSync } from '../sparkle/node_modules/esbuild/lib/main.js';
import { adaptJson, endpointOf, hasUnsafeInteger } from '../sparkle/src/script/bilibili/plus/json-playback';
const temp = fs.mkdtempSync(path.join(os.tmpdir(),'bili-json-test-'));
const bundle = path.join(temp,'json.js');
buildSync({entryPoints:[new URL('../sparkle/src/script/bilibili/plus/json-playback.ts',import.meta.url).pathname],bundle:true,format:'iife',platform:'browser',target:'es2022',outfile:bundle});
const source = fs.readFileSync(bundle,'utf8');
const primary='https://a.mcdn.bilivideo.cn/v1/resource/test?token=SECRET';
const mirror='https://upos-sz-mirrorcos.bilivideo.com/upgcxcode/a.m4s?deadline=9999999999&token=SECRET';
const item=()=>({base_url:primary,backup_url:[mirror],id:80,codecs:'avc1.640028',bandwidth:1200});
const data=()=>({code:0,data:{quality:80,accept_quality:[80,64],support_formats:[{quality:120,need_vip:true}],dash:{video:[item()],audio:[item()]}}});
function memory(values:Record<string,string>={}){return {read:(k:string)=>values[k]??null,write:(v:string,k:string)=>{values[k]=v;return true;}};}
const on=()=>memory({laincat_bili_optimize:'true'});
const endpoint='json-playurl';
function execute(value:any=data(), values:Record<string,string>={}, request:any={}, response:any={}){
 let count=0;let done:any;const logs:string[]=[];
 const body=typeof value==='string'?value:JSON.stringify(value);
 vm.runInNewContext(source,{URL,TextEncoder,console:{log:(x:string)=>logs.push(x)},$request:{url:'https://api.bilibili.com/x/player/playurl?token=SECRET',method:'GET',headers:{Cookie:'SECRET'},...request},$response:{status:200,headers:{'Content-Type':'application/json; charset=utf-8'},body,...response},$persistentStore:memory(values),$done:(x:any)=>{count++;done=x;}},{timeout:2000});
 assert.equal(count,1);assert.ok(!logs.join().includes('SECRET'));assert.ok(!logs.join().includes('https://'));
 return {done,logs};
}
test('JSON exact endpoint allowlist and host boundary',()=>{
 for(const p of ['/x/player/playurl','/x/player/wbi/playurl','/pgc/player/web/playurl'])assert.ok(endpointOf('https://api.bilibili.com'+p+'?test=1'));
 for(const u of ['http://api.bilibili.com/x/player/playurl','https://api.bilibili.com.evil.test/x/player/playurl','https://api.bilibili.com/x/player/playurl/extra','https://api.bilibili.com:444/x/player/playurl','https://user@api.bilibili.com/x/player/playurl','https://api.bilibili.com/x/player/playurl#x'])assert.equal(endpointOf(u),undefined);
});
test('JSON default observes without modifying response',()=>{const {done,logs}=execute();assert.deepEqual(Object.keys(done),[]);assert.ok(logs.some(x=>x.includes('observe')));});
test('JSON signed URL promotion preserves qualities, permission and unknown fields',()=>{
 const original=data();const result=JSON.parse(adaptJson(JSON.stringify(original),endpoint,on(),()=>{})!);
 assert.equal(result.data.dash.video[0].base_url,mirror);assert.equal(result.data.dash.video[0].backup_url[0],primary);
 assert.deepEqual(result.data.support_formats,original.data.support_formats);assert.deepEqual(result.data.accept_quality,original.data.accept_quality);assert.equal(result.data.dash.video[0].bandwidth,1200);
});
test('JSON camelCase and dual equal aliases updated consistently',()=>{
 const v:any=data();v.data.dash.video[0]={baseUrl:primary,base_url:primary,backupUrl:[mirror],backup_url:[mirror]};
 const result=JSON.parse(adaptJson(JSON.stringify(v),endpoint,on(),()=>{})!);const x=result.data.dash.video[0];
 assert.equal(x.baseUrl,mirror);assert.equal(x.base_url,mirror);assert.deepEqual(x.backupUrl,x.backup_url);
});
test('JSON conflicting URL aliases untouched',()=>{
 const v:any=data();v.data.dash.video[0].baseUrl=mirror;
 const result=JSON.parse(adaptJson(JSON.stringify(v),endpoint,on(),()=>{})!);assert.deepEqual(result.data.dash.video[0],v.data.dash.video[0]);
});
test('JSON conflicting backup aliases untouched',()=>{
 const v:any=data();v.data.dash.video[0].backupUrl=[primary];
 const result=JSON.parse(adaptJson(JSON.stringify(v),endpoint,on(),()=>{})!);assert.deepEqual(result.data.dash.video[0],v.data.dash.video[0]);
});
test('JSON no backup does not fabricate one',()=>{
 const v:any=data();v.data.dash.video[0]={base_url:primary};v.data.dash.audio=[];
 assert.equal(adaptJson(JSON.stringify(v),endpoint,on(),()=>{}),undefined);
});
test('JSON PGC known result envelopes',()=>{
 for(const result of [{dash:data().data.dash},{video_info:{dash:data().data.dash}}]){
  const {done}=execute({code:0,result},{laincat_bili_optimize:'true'},{url:'https://api.bilibili.com/pgc/player/web/playurl?ep_id=1'});
  assert.ok(done.body.includes(mirror));assert.ok(!JSON.parse(done.body).data);
 }
});
test('JSON Dolby and FLAC gated by extended switch',()=>{
 const v:any=data();v.data.dash.dolby={audio:[item(),item()],type:2};v.data.dash.flac={audio:item(),display:true};
 const untouched=JSON.parse(adaptJson(JSON.stringify(v),endpoint,on(),()=>{})!);assert.deepEqual(untouched.data.dash.dolby,v.data.dash.dolby);assert.deepEqual(untouched.data.dash.flac,v.data.dash.flac);
 const enabled=memory({laincat_bili_optimize:'true',laincat_bili_extendedStreams:'true'});
 const result=JSON.parse(adaptJson(JSON.stringify(v),endpoint,enabled,()=>{})!);assert.equal(result.data.dash.dolby.audio[1].base_url,mirror);assert.equal(result.data.dash.flac.audio.base_url,mirror);assert.equal(result.data.dash.flac.display,true);
});
test('JSON unsafe numeric integers fall through; string IDs remain valid',()=>{
 assert.equal(hasUnsafeInteger('{"x":9007199254740993}'),true);assert.equal(hasUnsafeInteger('{"x":1e30}'),true);
 assert.equal(hasUnsafeInteger('{"x":"9007199254740993","y":1.5}'),false);
 const body=JSON.stringify(data()).replace('"code":0','"code":0,"unsafe":9007199254740993');assert.equal(adaptJson(body,endpoint,on(),()=>{}),undefined);
});
test('JSON only known success envelope modified',()=>{
 for(const v of [{...data(),code:-10403},{code:0,result:data().data},{code:0,data:{durl:[{url:primary,backup_url:[mirror]}]}},{code:0,data:{dash:[]}}])assert.equal(adaptJson(JSON.stringify(v),endpoint,on(),()=>{}),undefined);
});
test('JSON master disabled produces no logs or mutation',()=>{const {done,logs}=execute(data(),{laincat_bili_enabled:'false',laincat_bili_optimize:'true'});assert.deepEqual(Object.keys(done),[]);assert.equal(logs.length,0);});
test('JSON non-GET, failed HTTP and non-JSON fail open',()=>{
 for(const [req,res] of [[{method:'POST'},{}],[{},{status:403}],[{},{headers:{'content-type':'text/html'}}],[{},{body:new Uint8Array([1])}]]){const {done}=execute(data(),{laincat_bili_optimize:'true'},req,res);assert.deepEqual(Object.keys(done),[]);}
});
test('JSON malformed, oversized or unsupported nested data fail open once',()=>{
 for(const v of ['{SECRET',' '.repeat(2097153),{code:0,data:{dash:{video:[null]}}},{code:0,data:{dash:{video:Array(257).fill(item())}}}]){const {done}=execute(v,{laincat_bili_optimize:'true'});assert.deepEqual(Object.keys(done),[]);}
});
test('JSON matching succeeds for WBI endpoint without changing signed query',()=>{
 const {done}=execute(data(),{laincat_bili_optimize:'true'},{url:'https://api.bilibili.com/x/player/wbi/playurl?w_rid=SECRET'});assert.equal(JSON.parse(done.body).data.dash.audio[0].base_url,mirror);
});
test('JSON current module response patterns do not overlap with new paths',()=>{
 const module=fs.readFileSync(new URL('../release/Bilibili.Compatibility.sgmodule',import.meta.url),'utf8');
 for(const line of module.split('\n').filter(x=>x.includes('type=http-response') && !x.startsWith('bilibili.plus.json-playback ='))){const match=line.match(/pattern=(.*?),(?:argument|requires-body)=/);if(!match)continue;const r=new RegExp(match[1]);for(const p of ['/x/player/playurl','/x/player/wbi/playurl','/pgc/player/web/playurl'])assert.equal(r.test('https://api.bilibili.com'+p+'?x=1'),false);}
});
process.on('exit',()=>fs.rmSync(temp,{recursive:true,force:true}));
test('non-finite JSON numbers fail open rather than becoming null',()=>{
 for(const value of ['1e400','-1e400']){
  const body=JSON.stringify(data()).replace('"code":0','"code":0,"unknown":'+value);
  assert.equal(hasUnsafeInteger(body),true);
  assert.deepEqual(Object.keys(execute(body,{laincat_bili_optimize:'true'}).done),[]);
 }
});
