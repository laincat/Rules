import test from 'node:test';
import assert from 'node:assert/strict';
import { telemetryResponse } from '../sparkle/src/script/bilibili/plus/telemetry';
const enabled = { read: (k: string) => k === 'laincat_bili_telemetry' ? 'true' : null };
const req = { url: 'https://data.bilibili.com/log/web?private=SECRET', method: 'POST', headers: { Origin: 'https://www.bilibili.com', Cookie: 'SECRET' } };
test('telemetry defaults off', () => assert.deepEqual(telemetryResponse(req), {}));
test('opt-in gets local success without body or private headers', () => {
 const result = telemetryResponse(req, enabled);
 assert.equal(result.response?.status, 200); assert.equal(result.response?.body, 'ok');
 assert.ok(!JSON.stringify(result).includes('SECRET'));
});
test('master off overrides telemetry', () => assert.deepEqual(telemetryResponse(req, {read:k => k === 'laincat_bili_enabled' ? 'false':'true'}), {}));
test('malformed switch does not enable', () => assert.deepEqual(telemetryResponse(req,{read:()=> 'yes'}),{}));
test('storage failure fails open',()=>assert.deepEqual(telemetryResponse(req,{read:()=>{throw Error('SECRET')}}),{}));
test('GET web beacon supported',()=>assert.equal(telemetryResponse({...req,method:'GET'},enabled).response?.status,200));
test('no web context means unchanged',()=>assert.deepEqual(telemetryResponse({...req,headers:{}},enabled),{}));
test('Referer context accepted',()=>assert.equal(telemetryResponse({...req,headers:{Referer:'https://live.bilibili.com/123?private=SECRET'}},enabled).response?.headers?.['Access-Control-Allow-Origin'],'https://live.bilibili.com'));
for(const origin of ['null','https://bilibili.com.attacker.test','https://evil.test','http://www.bilibili.com','https://user@www.bilibili.com','https://www.bilibili.com:444']){
 test(`invalid origin fails open: ${origin}`,()=>assert.deepEqual(telemetryResponse({...req,headers:{Origin:origin,Referer:'https://www.bilibili.com/'}},enabled),{}));
}
for(const url of ['https://data.bilibili.com/v2/log/web','https://data.bilibili.com/v/web/web_page_view','https://api.bilibili.com/x/internal/gaia-gateway/ExClimbWuzhi','https://api.bilibili.com/x/v2/history/report','https://data.bilibili.com/log/web/','https://data.bilibili.com.attacker.test/log/web','https://u:p@data.bilibili.com/log/web','http://data.bilibili.com/log/web','https://data.bilibili.com:444/log/web']){
 test(`non-target passes: ${url}`,()=>assert.deepEqual(telemetryResponse({...req,url},enabled),{}));
}
test('OPTIONS is unchanged',()=>assert.deepEqual(telemetryResponse({...req,method:'OPTIONS'},enabled),{}));
test('headers matched case-insensitively',()=>assert.equal(telemetryResponse({...req,headers:{oRiGiN:'https://www.bilibili.com'}},enabled).response?.status,200));

test('ambiguous Origin headers fail open rather than falling back',()=>assert.deepEqual(telemetryResponse({...req,headers:{Origin:'https://www.bilibili.com',origin:'https://evil.test',Referer:'https://www.bilibili.com'}},enabled),{}));
test('bundled Surge entrypoint completes exactly once with no logging',async()=>{
 const {build} = await import('../sparkle/node_modules/esbuild/lib/main.js');
 const vm = await import('node:vm');
 const result = await build({entryPoints:[new URL('../sparkle/src/script/bilibili/plus/telemetry.ts', import.meta.url).pathname],bundle:true,write:false,format:'iife',platform:'browser',target:'es2022'});
 let count=0; let done:any; const logs:any[]=[];
 vm.runInNewContext(result.outputFiles[0].text,{URL,$request:req,$persistentStore:enabled,$done:(r:any)=>{count++;done=r},console:{log:(...args:any[])=>logs.push(args)}},{timeout:1000});
 assert.equal(count,1);assert.equal(done.response.status,200);assert.equal(logs.length,0);
});
