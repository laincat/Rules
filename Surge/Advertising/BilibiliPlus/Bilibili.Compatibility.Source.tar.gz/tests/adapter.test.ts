import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { gzipSync, gunzipSync } from 'node:zlib';
import { UnknownFieldHandler, WireType } from '../sparkle/node_modules/@protobuf-ts/runtime/build/es2015/index.js';
import { PlayViewReply } from '../sparkle/src/proto/bilibili/app/playurl/v1/playurl';
import { PlayViewUniteReply } from '../sparkle/src/proto/bilibili/app/playerunite/v1/player';
import { PlayViewReply as PgcReply } from '../sparkle/src/proto/bilibili/pgc/gateway/player/v2/playurl';
import { DynAllReply, DynamicType } from '../sparkle/src/proto/bilibili/app/dynamic/v2/dynamic';
import { defaults, isPcdn, isPcdnUrl, signatureDeadline, isFreshCandidate, parseHttp, optimizeVideo, readSettings, runAdapter } from '../sparkle/src/script/bilibili/protobuf/pcdn-adapter';
const secret = 'SECRET_SIGNED_TOKEN';
const primary = `https://a.mcdn.bilivideo.cn/v1/resource/abc?token=${secret}`;
const mirror = `https://upos-sz-mirrorcos.bilivideo.com/upgcxcode/abc.m4s?deadline=9999999999&token=${secret}`;
const dash = () => ({ baseUrl: primary, backupUrl: [mirror, primary] });
const video = () => ({ streamList: [{ dashVideo: dash() }], dashAudio: [dash()] });
const settings = { ...defaults, optimize: true };
const source = fs.readFileSync(new URL('../release/Bilibili.Compatibility.js', import.meta.url), 'utf8');
const memory = (values: Record<string, string> = {}) => ({ read: (k: string) => values[k] ?? null, write: (v: string, k: string) => { values[k] = v; return true; } });
function frame(body: Uint8Array, compressed = false) {
    if (compressed) body = gzipSync(body);
    const out = new Uint8Array(body.length + 5);
    new DataView(out.buffer).setUint32(1, body.length);
    out[0] = compressed ? 1 : 0; out.set(body, 5); return out;
}
async function execute(path: string, body: Uint8Array, values = {}, extra: Record<string, any> = {}) {
    let calls = 0; const logs: string[] = [];
    let finish: (x: any) => void = () => {};
    const result = new Promise<any>(resolve => { finish = resolve; });
    const context = { URL, Uint8Array, ArrayBuffer, DataView, TextEncoder, TextDecoder,
        $request: { url: `https://grpc.biliapi.net/${path}`, method: 'POST', headers: { cookie: secret } },
        $response: { body, status: 200, headers: { 'content-type': 'application/grpc', 'grpc-status': '0' } },
        $persistentStore: memory(values), $utils: { ungzip: (b: Uint8Array) => new Uint8Array(gunzipSync(b)) },
        $done: (r: any) => { calls++; finish(r); }, console: { log: (...x: any[]) => logs.push(x.join(' ')) }, ...extra };
    vm.runInNewContext(source, context, { timeout: 2000 });
    const done = await Promise.race([result, new Promise((_, reject) => setTimeout(() => reject(new Error('no $done')), 2000))]);
    assert.equal(calls, 1); assert.ok(!logs.join().includes(secret));
    return { done, logs };
}
for (const host of ['a.mcdn.bilivideo.cn','a.mcdn.bilivideo.com','mcdn.bilivideo.net','szbdyd.com','x.mountaintoys.cn','hw-sh-pcdn-1.biliapi.net','upos-sz-302ppio.bilivideo.com']) {
    test(`classify ${host}`, () => assert.equal(isPcdn(host), true));
}
test('suffix boundary does not match attacker domain', () => assert.equal(isPcdn('szbdyd.com.attacker.test'), false));
test('reject malformed URLs and embedded credentials', () => { for (const u of ['foo','javascript:foo','https://u:p@x.test/a']) assert.equal(parseHttp(u), undefined); });
test('default settings observe only', () => { const v=video(); assert.equal(optimizeVideo(v,defaults).changed,0); assert.equal(v.streamList[0].dashVideo.baseUrl,primary); });
test('select existing signed mirror without changing signature, retain original fallback', () => { const v=video(); assert.equal(optimizeVideo(v,settings).changed,2); assert.equal(v.dashAudio[0].baseUrl,mirror); assert.equal(v.dashAudio[0].backupUrl[0],primary); });
test('no known backup stays original', () => { const v=video(); v.dashAudio[0].backupUrl=['https://unknown.test/foo']; optimizeVideo(v,settings); assert.equal(v.dashAudio[0].baseUrl,primary); });
test('all PCDN backups stay original', () => { const v=video(); v.dashAudio[0].backupUrl=[primary]; optimizeVideo(v,settings); assert.equal(v.dashAudio[0].baseUrl,primary); });
test('do not change healthy CDN primary', () => { const v=video(); v.dashAudio[0].baseUrl=mirror; assert.equal(optimizeVideo(v,settings).changed,1); });
test('HTTP backup never selected', () => { const v=video(); v.dashAudio[0].backupUrl=[mirror.replace('https:','http:')]; optimizeVideo(v,settings); assert.equal(v.dashAudio[0].baseUrl,primary); });
test('master off prevents custom modifications', () => assert.equal(optimizeVideo(video(),{...settings,enabled:false}).changed,0));
test('malformed and absent persistent values use defaults', () => assert.deepEqual(readSettings(memory({laincat_bili_optimize:'oops'})),defaults));
test('BoxJS booleans and numeric strings', () => assert.deepEqual(readSettings(memory({laincat_bili_enabled:'0',laincat_bili_optimize:'true',laincat_bili_diagnostics:'false'})),{enabled:false,optimize:true,diagnostics:false}));
test('log cap, privacy and independent endpoint counters', () => { const s=memory(); const logs:string[]=[]; for(let i=0;i<120;i++)runAdapter(video(),'unite',s,x=>logs.push(x)); assert.equal(logs.length,100); runAdapter(video(),'pgc',s,x=>logs.push(x));assert.equal(logs.length,101);assert.ok(!logs.join().includes(secret));assert.ok(!logs.join().includes('https')); });
test('diagnostics can be disabled', () => {const logs:string[]=[];runAdapter(video(),'unite',memory({laincat_bili_diagnostics:'false'}),x=>logs.push(x));assert.equal(logs.length,0);});
const routes: [string, any][] = [
    ['bilibili.app.playurl.v1.PlayURL/PlayView', PlayViewReply],
    ['bilibili.app.playerunite.v1.Player/PlayViewUnite', PlayViewUniteReply],
    ['bilibili.pgc.gateway.player.v2.PlayURL/PlayView', PgcReply],
];
for(const [path,codec] of routes) {
    test(`full bundle ${path}: fields and unknowns survive`, async () => {
        const m=codec.create({adapterVideoInfo:video()});
        UnknownFieldHandler.onRead(codec.typeName,m,90,WireType.Varint,new Uint8Array([7]));
        UnknownFieldHandler.onRead('DashVideo',m.adapterVideoInfo.streamList[0].dashVideo,20,WireType.Varint,new Uint8Array([11]));
        const {done}=await execute(path,frame(codec.toBinary(m)),{laincat_bili_optimize:'true'});
        const parsed=codec.fromBinary(done.body.subarray(5));
        assert.equal(parsed.adapterVideoInfo.dashAudio[0].baseUrl,mirror);
        assert.equal(UnknownFieldHandler.list(parsed)[0].no,90);
        assert.equal(UnknownFieldHandler.list(parsed.adapterVideoInfo.streamList[0].dashVideo)[0].no,20);
    });
}
test('gzip unary response works',async()=>{const {done}=await execute(routes[0][0],frame(PlayViewReply.toBinary(PlayViewReply.create({adapterVideoInfo:video()})),true),{laincat_bili_optimize:'true'});assert.equal(done.body[0],0);assert.equal(PlayViewReply.fromBinary(done.body.subarray(5)).adapterVideoInfo?.dashAudio[0].baseUrl,mirror);});
test('original Surge module playback adjustments still applied',async()=>{const m=PlayViewReply.create({playArc:{backgroundPlayConf:{isSupport:false,disabled:true,unsupportScene:['1']}}});const {done}=await execute(routes[0][0],frame(PlayViewReply.toBinary(m)));const p=PlayViewReply.fromBinary(done.body.subarray(5));assert.equal(p.playArc?.backgroundPlayConf?.isSupport,true);assert.equal(p.playArc?.backgroundPlayConf?.disabled,false);});
test('original Surge module feed advertising filtering retained',async()=>{const m=DynAllReply.create({dynamicList:{list:[{cardType:DynamicType.AD},{cardType:DynamicType.LIVE_RCMD},{cardType:DynamicType.AV}]}});const {done}=await execute('bilibili.app.dynamic.v2.Dynamic/DynAll',frame(DynAllReply.toBinary(m)));assert.equal(DynAllReply.fromBinary(done.body.subarray(5)).dynamicList?.list.length,1);});
for (const [name,body] of [['short',new Uint8Array([0])],['length mismatch',new Uint8Array([0,0,0,0,3])],['multi frame',new Uint8Array(10)],['unknown flag',new Uint8Array([2,0,0,0,0])],['malformed protobuf',frame(new Uint8Array([255]))]] as const) {
    test(`invalid ${name} falls through without raw logs`,async()=>{const {done}=await execute(routes[0][0],body);assert.deepEqual(Object.keys(done),[]);});
}
test('HTTP failure falls through',async()=>{const {done}=await execute(routes[0][0],frame(new Uint8Array()),{},{$response:{body:frame(new Uint8Array()),status:500,headers:{}}});assert.deepEqual(Object.keys(done),[]);});
test('single module uses one pinned response script and contains no publication claim',()=>{const m=fs.readFileSync(new URL('../release/Bilibili.Compatibility.sgmodule',import.meta.url),'utf8');assert.equal((m.match(/bilibili.protobuf.response =/g)||[]).length,1);assert.ok(m.includes(process.env.ASSET_BASE_URL || 'https://example.invalid/bilibili'));assert.ok(!m.includes('refs/heads/master/dist/bilibili.protobuf.response.js'));});
test('BoxJS keys match code defaults',()=>{const b=JSON.parse(fs.readFileSync(new URL('../release/Bilibili.Compatibility.boxjs.json',import.meta.url),'utf8'));for(const s of b.apps[0].settings)assert.equal(s.val,defaults[s.id.replace('laincat_bili_','') as keyof typeof defaults]);});
test('module playback and general response patterns never overlap for known routes',()=>{
 const m=fs.readFileSync(new URL('../release/Bilibili.Compatibility.sgmodule',import.meta.url),'utf8');
 const lines=m.split('\n');
 const general=lines.find(x=>x.startsWith('bilibili.protobuf.response ='))!;
 const playback=lines.find(x=>x.startsWith('bilibili.compat.playback ='))!;
 const regex=(line:string)=>new RegExp(line.match(/pattern=(.*?),argument=/)![1]);
 for(const host of ['grpc.biliapi.net','app.bilibili.com'])for(const [path] of routes){
   const url=`https://${host}/${path}`;assert.ok(regex(playback).test(url));assert.ok(!regex(general).test(url));
 }
 assert.ok(regex(general).test('https://grpc.biliapi.net/bilibili.app.dynamic.v2.Dynamic/DynAll'));
 assert.ok(!regex(playback).test('https://grpc.biliapi.net/bilibili.app.dynamic.v2.Dynamic/DynAll'));
 assert.ok(general.includes('max-size=-1'));assert.ok(playback.includes('max-size=2097152'));
});
test('decoded oversized payload fails open even if gzip size advertises small',async()=>{
 const compressed=frame(gzipSync(new Uint8Array([1])));compressed[0]=1;
 const {done}=await execute(routes[0][0],compressed,{},{$utils:{ungzip:()=>new Uint8Array(2097153)}});
 assert.deepEqual(Object.keys(done),[]);
});
test('malformed nested protobuf fails open without token logs',async()=>{
 const {done}=await execute(routes[0][0],frame(new Uint8Array([10,2,255,255])));assert.deepEqual(Object.keys(done),[]);
});
test('gRPC failed status does not rewrite',async()=>{
 const b=frame(new Uint8Array());const {done}=await execute(routes[0][0],b,{},{$response:{body:b,status:200,headers:{'grpc-status':'7'}}});assert.deepEqual(Object.keys(done),[]);
});
test('master off still retains original Surge module playback handling',async()=>{
 const m=PlayViewReply.create({adapterVideoInfo:video(),playArc:{backgroundPlayConf:{isSupport:false,disabled:true}}});
 const {done,logs}=await execute(routes[0][0],frame(PlayViewReply.toBinary(m)),{laincat_bili_enabled:'false'});
 const p=PlayViewReply.fromBinary(done.body.subarray(5));assert.equal(p.adapterVideoInfo?.dashAudio[0].baseUrl,primary);assert.equal(p.playArc?.backgroundPlayConf?.disabled,false);assert.equal(logs.length,0);
});

test('mirror URL with os=mcdn is classified as PCDN',()=>{
 assert.equal(isPcdnUrl(new URL(mirror+'&os=mcdn')),true);
 assert.equal(isPcdnUrl(new URL(mirror+'&os=upos')),false);
});
test('os=mcdn primary can switch to a clean listed mirror',()=>{
 const v=video();v.dashAudio[0]={baseUrl:mirror+'&os=mcdn',backupUrl:[mirror]};
 assert.equal(optimizeVideo(v,settings).changed,2);assert.equal(v.dashAudio[0].baseUrl,mirror);
});
test('os=mcdn backup is skipped even on an ordinary mirror hostname',()=>{
 const v=video();v.dashAudio[0].backupUrl=[mirror+'&os=mcdn',mirror];
 optimizeVideo(v,settings);assert.equal(v.dashAudio[0].baseUrl,mirror);
});
test('only os=mcdn mirror backup leaves primary unchanged',()=>{
 const v=video();v.dashAudio[0].backupUrl=[mirror+'&os=mcdn'];
 const stats=optimizeVideo(v,settings);assert.equal(v.dashAudio[0].baseUrl,primary);assert.equal(stats.noAlternative,1);
});

test('known expired backup is not selected',()=>{
 const v=video();v.dashAudio[0].backupUrl=[mirror.replace('9999999999','1')];
 optimizeVideo(v,settings);assert.equal(v.dashAudio[0].baseUrl,primary);
});
test('signature with sixty seconds or less is not selected',()=>{
 assert.equal(isFreshCandidate(new URL(mirror.replace('9999999999','1060')),1000),false);
 assert.equal(isFreshCandidate(new URL(mirror.replace('9999999999','1061')),1000),true);
});
test('Akamai token can expire before the deadline',()=>{
 const u=new URL(mirror+'&hdnts=exp=1~acl=*~hmac=synthetic');
 assert.equal(signatureDeadline(u),1);assert.equal(isFreshCandidate(u),false);
});
test('earlier of deadline and token is used',()=>{
 assert.equal(signatureDeadline(new URL(mirror.replace('9999999999','2000')+'&hdnts=exp=3000~hmac=synthetic')),2000);
});
test('unknown expiry is not claimed invalid',()=>{
 const u=new URL('https://upos-sz-mirrorcos.bilivideo.com/upgcxcode/test?signature=synthetic');
 assert.equal(signatureDeadline(u),0);assert.equal(isFreshCandidate(u),true);
});
