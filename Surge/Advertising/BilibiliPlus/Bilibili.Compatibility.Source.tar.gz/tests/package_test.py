import subprocess
import tempfile
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class PackageTests(unittest.TestCase):
    def test_output_cannot_be_inside_input_tree(self):
        for name in ('release/should-not-exist.tar.gz', 'sparkle/should-not-exist.tar.gz', 'README.md'):
            result = subprocess.run(['python', str(ROOT/'package.py'), '--output', str(ROOT/name)], capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('outside all packaging inputs', result.stderr)
            if name.endswith('.tar.gz'): self.assertFalse((ROOT/name).exists())

    def test_same_inputs_reproduce_same_bytes(self):
        with tempfile.TemporaryDirectory() as directory:
            paths = [Path(directory)/'first.tar.gz', Path(directory)/'second.tar.gz']
            for path in paths:
                subprocess.run(['python',str(ROOT/'package.py'),'--output',str(path)],check=True,capture_output=True)
            self.assertEqual(paths[0].read_bytes(), paths[1].read_bytes())
