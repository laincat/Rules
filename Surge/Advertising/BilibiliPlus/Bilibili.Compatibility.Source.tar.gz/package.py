#!/usr/bin/env python3
"""Package complete corresponding source without dependencies, credentials, or local git state."""
import argparse
import gzip
import hashlib
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INPUTS = ['README.md', 'build.mjs', 'package.py', 'tests', 'test-results.txt', 'SHA256SUMS',
          'THIRD_PARTY_LICENSES.txt', 'licenses', 'sparkle', 'release']
EXCLUDED = {'node_modules', '.git', '__pycache__', '.DS_Store'}

def package(output):
    for name in INPUTS:
        source = ROOT/name
        if output == source or (source.is_dir() and output.is_relative_to(source)):
            raise ValueError('Output must be outside all packaging inputs')
    artifacts = sorted((ROOT/'release').iterdir())
    (ROOT/'SHA256SUMS').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  release/'+f.name+'\n' for f in artifacts if f.is_file()))
    files = []
    for name in INPUTS:
        source = ROOT/name
        if not source.exists(): raise FileNotFoundError(source)
        candidates = source.rglob('*') if source.is_dir() else [source]
        for path in candidates:
            relative = path.relative_to(ROOT)
            if any(part in EXCLUDED for part in relative.parts): continue
            if path.is_symlink(): raise ValueError('Unexpected symlink: '+str(relative))
            if path.is_file(): files.append(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('wb') as raw, gzip.GzipFile(fileobj=raw, filename='', mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as archive:
            for path in sorted(files):
                info = archive.gettarinfo(str(path), arcname=str(path.relative_to(ROOT)))
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                info.mode = 0o755 if info.mode & 0o111 else 0o644
                with path.open('rb') as stream: archive.addfile(info, stream)
    print(hashlib.sha256(output.read_bytes()).hexdigest(), output)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    package(parser.parse_args().output.resolve())
